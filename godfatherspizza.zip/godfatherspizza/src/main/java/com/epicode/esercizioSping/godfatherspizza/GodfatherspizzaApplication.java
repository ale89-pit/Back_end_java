package com.epicode.esercizioSping.godfatherspizza;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GodfatherspizzaApplication {

	public static void main(String[] args) {
		SpringApplication.run(GodfatherspizzaApplication.class, args);
	}

}
