package com.epicode.esercizioSping.godfatherspizza;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GodfatherspizzaApplicationTests {

	@Test
	void contextLoads() {
	}

}
